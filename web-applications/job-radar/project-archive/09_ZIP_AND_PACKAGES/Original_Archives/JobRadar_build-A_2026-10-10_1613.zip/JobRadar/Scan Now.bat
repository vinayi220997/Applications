@echo off
title Job Radar - scan
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
%PY% -m jobradar run
pause
