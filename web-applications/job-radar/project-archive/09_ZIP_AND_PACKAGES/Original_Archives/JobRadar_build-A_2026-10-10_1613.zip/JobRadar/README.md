# Job Radar: a local job discovery agent

Job Radar runs on your own computer. You describe the job you want, it asks a few questions to fill in what's missing (location, experience, work arrangement, skills, pay, things to avoid), and then it scans job sources, removes duplicates and closed jobs, ranks what's left against the search, and gives you direct application links. It runs when you start it, or on a schedule you choose.

Several people can use one installation. Each person adds their own search and, if they like, their own email address for the daily report.

## 1. Install (Windows, about 5 minutes)

1. Install **Python 3.9 or newer** from https://www.python.org/downloads/. On the first installer screen, tick **"Add python.exe to PATH"**.
2. Unzip this folder somewhere permanent, for example `Documents\JobRadar`.
3. Double-click **`Start Job Radar.bat`**. Your browser opens at `http://127.0.0.1:8765`.

There's nothing else to install. Job Radar uses Python's standard library plus a bundled PDF reader in `vendor/`. On macOS or Linux, run `./start.sh`.

## 2. Use it

1. Under **Find jobs**, describe the job in your own words, for example *"Python backend developer, Django and AWS, fintech, Bengaluru or remote"*.
2. Answer the follow-up questions. It asks only about what you didn't already mention.
3. Press **Save and scan now**. A first scan takes about 1 to 3 minutes. Results appear on the right with:
   - the match score, why it matches, and what's missing or uncertain
   - the job description
   - the posting date (or "unknown" when the source doesn't give one), when Job Radar first saw it, and when it was last verified
   - whether the job is Verified active, Appears active, or Unable to verify
   - **Apply**, the company careers page, and the original source
4. Mark jobs as **Save**, **Applied** or **Dismiss**. Applied and dismissed jobs aren't reported again.

### Attachments, screenshots and voice

Under the message box in **Find jobs** there are three buttons:

- **Attach**: add a resume or a job post as a PDF, Word (.docx), text, image or audio file. You can also drag files onto the chat box. Job Radar reads the file and fills in your roles, skills, experience and location, so it asks fewer questions. A resume gives it your background, and a job post gives it the kind of job you want.
- **Screenshot**: choose a window or browser tab, for example a job post open on LinkedIn or Naukri, and it's captured into the chat. You can also press **Win+Shift+S** and then **Ctrl+V** in the message box.
- **Voice**: press it, describe what you want, then press it again to stop. While you speak, your words are typed into the message box. This works in Microsoft Edge and Google Chrome. The recording is saved with your search.

PDF and Word files are read entirely on your computer. To read text from images and screenshots, add an Anthropic API key in Settings. Without a key, the image is still saved, and Job Radar asks you to type the key details. Attachments are stored in `data/attachments` on this computer and are deleted when you delete the search.

## 3. Schedule it

In the **Schedule** card, choose a start time, the days, and optionally "every N hours", then press **Save schedule**.

- This creates a Windows Task Scheduler task called `JobRadar\DailyScan`. The scan runs even when the Job Radar window is closed.
- If the computer was off or asleep at the scheduled time, the scan runs as soon as it's back on.
- **Turn off** removes the task.

You can do the same from a terminal:

```
py -m jobradar schedule 08:00                         # every day at 8:00 AM
py -m jobradar schedule 07:30 --days MON,TUE,WED,THU,FRI
py -m jobradar schedule 09:00 --every-hours 4         # 9 AM, then every 4 hours
py -m jobradar unschedule
```

To scan right now without opening the app, double-click **`Scan Now.bat`** or run `py -m jobradar run`.

## 4. Email reports (optional)

Open **Settings** and fill in:

- **Send reports by email**: tick this box.
- **Sending Gmail address**: the account the reports are sent from.
- **Gmail app password**: create one at myaccount.google.com → Security → App passwords. This needs 2-Step Verification turned on.

Press **Save settings**, then **Send test email**. Each search's report goes to the email address saved with that search. The password is stored only in `config/settings.json` on this computer. Instead of saving it there, you can set the `JOBRADAR_SMTP_PASSWORD` environment variable.

## 4a. Not getting emails? Press Check setup

The **Check setup** button (or `py -m jobradar doctor`) tests each step and tells you what to fix:

1. **Email sending is off.** This is the default, so reports are only saved in the app. Open **Settings**, tick *Send reports by email*, enter the Gmail address that sends the reports and a Gmail **app password** (not your normal password), then **Save** and **Send test email**.
2. **Gmail rejected the sign-in.** Create an app password at myaccount.google.com/apppasswords. 2-Step Verification must be on.
3. **The search has no email address.** Press **Add email** on the search card.
4. **No new matches.** Widen the search: add more job titles or cities, allow remote, or remove the minimum salary. You can also add your target companies' careers pages.
5. **Job sites are blocked.** An office network or firewall can block them.
6. **Check your spam folder** for the first email from Job Radar.

When email is working, press **Email results now** on a search to receive every open match straight away. Jobs that were found while email wasn't working are included in the next email that goes out.

## 5. Where jobs come from

| Source | How it's read | Status shown |
|---|---|---|
| Employer job boards on Greenhouse, Lever, Ashby, SmartRecruiters, Workable and Recruitee | The employer's own public job-board API | **Verified active** while the job is in the live feed. It's marked closed when it disappears. |
| Remotive, Remote OK, Jobicy, We Work Remotely | Their public APIs or RSS feeds (used for remote searches) | Appears active, or the result of an application-page check |
| Adzuna (optional, free key from developer.adzuna.com) | An authorised aggregator API that covers Indian job boards | Same as above |
| LinkedIn, Naukri, Indeed, Glassdoor, Foundit, Wellfound, Dice | **Not scraped**, because they don't offer an open API | Every report includes pre-filled search links for these sites, already filtered to the last 24 hours |

`config/companies.json` is a starter list of about 130 employer boards. These are guesses, so every scan checks them, keeps the ones that respond, and sets aside the ones that don't exist (they're checked again every 14 days). To add your own target companies, go to **Settings → Add a company's careers page** and paste a link such as `https://jobs.lever.co/company`. The more target companies you add, the better your coverage.

## 6. Rules the agent follows

- It never invents jobs, posting dates or links. If a source gives no date, the date is shown as *unknown*. The date Job Radar first saw a job is never presented as the posting date.
- A page loading successfully isn't treated as proof that a job is open. Third-party jobs on your shortlist are checked for "no longer accepting" messages, dead links, and redirects to a general page.
- Duplicates are merged across sources, and the employer's own link is preferred. Two different openings with the same title are never merged.
- An unchanged job is never reported twice. A job that changes or is reposted is flagged.
- If some sources fail, the scan continues with the rest, and the failures are listed in the report. A partial scan is never reported as complete.
- It never applies for jobs and never sends your data anywhere except the email address you set.

## 7. How matching works

First, hard filters remove jobs that don't fit: the wrong location, a remote job limited to another country, too much required experience, a seniority level that's too high, a verified salary below your minimum, internships (unless you want one), and anything on your exclude list.

Then each remaining job gets a weighted score out of 100:

`0.30 skills + 0.25 experience + 0.20 responsibilities + 0.10 location + 0.10 preferences + 0.05 compensation`

You can change these weights in `config/settings.json`.

A skill that the job doesn't mention is listed as *not mentioned*. A skill the job asks for that isn't in your search is listed as *not established in your profile*. Neither is treated as a confirmed gap.

Optional: add an Anthropic API key in Settings so Job Radar can understand free-text descriptions better.

## 8. Files

```
Start Job Radar.bat   open the app
Scan Now.bat          run one scan
config/               settings.json (created when you save settings), companies.json
data/                 jobradar.db (all jobs, history, searches), logs
reports/              one HTML report per search per scan
jobradar/             the agent's code
tests/                offline tests: py -m unittest discover tests
```
